FMOD Cinder Block
-----------------
Core Cinder support for FMOD version 4.44.06 on Mac OS X, iOS and MSW.